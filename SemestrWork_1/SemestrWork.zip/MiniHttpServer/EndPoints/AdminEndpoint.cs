﻿using MiniHttpServer.Framework.Attributes;
using MiniHttpServer.Framework.Core.Abstract;
using MiniHttpServer.Framework.share;
using MyORMLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MiniHttpServer.EndPoints;

[Endpoint("admin")]
public class AdminEndpoint : BaseEndPoint
{
    [HttpGet]
    public IResponseResult AdminListPage()
    {
        return Page(@"Static/Pages/Admin/Admin_EventPage.html", null);
    }

    [HttpPost("create")]
    public IResponseResult CreateTour()
    {
        var orm = new ORMContext(SettingsManager.Instance.Settings.ConnectionString);

        var tour = new Models.Tour();
        var tourProps = tour.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

        foreach (var prop in tourProps)
        {
            if (prop.Name != "Id")
            {
                object value = GetValue(FormData, prop.Name, prop.PropertyType);
                prop.SetValue(tour, value ?? string.Empty);
            }
        }

        //foreach (var prop in tourProps)
        //{
        //    if (!FormData.ContainsKey(prop.Name))
        //    {
        //        if (prop.Name != "Id")
        //        {
        //            prop.SetValue(tour, string.Empty);
        //            continue;
        //        }
        //    }
        //    prop.SetValue(tour, GetValue(FormData, prop.Name, prop.PropertyType));
        //}

        orm.AddToTable<Models.Tour>(tour, "Tours");

        return RefreshPage();
    }

    //public static object GetValue(Dictionary<string, string> formData, string key, Type type)
    //{
    //    if (!formData.ContainsKey(key)) return null;

    //    string value = formData[key];
    //    if (string.IsNullOrEmpty(value)) return null;

    //    try
    //    {
    //        return Convert.ChangeType(value, type);
    //    }
    //    catch
    //    {
    //        return null;
    //    }
    //}

    public static object GetValue(Dictionary<string, string> formData, string key, Type type)
    {
        if (!formData.ContainsKey(key) || string.IsNullOrEmpty(formData[key]))
        {
            // Возвращаем default значение для типа
            return type.IsValueType ? Activator.CreateInstance(type) : null;
        }

        string value = formData[key];
        try
        {
            return Convert.ChangeType(value, type);
        }
        catch
        {
            return type.IsValueType ? Activator.CreateInstance(type) : null;
        }
    }
}
