﻿using MiniHttpServer.Framework.Attributes;
using MiniHttpServer.Framework.Core.Abstract;
using MiniHttpServer.Framework.share;
using MiniHttpServer.Models;
using MyORMLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MiniHttpServer.EndPoints;

[Endpoint("event")]
public class EventEndpoint : BaseEndPoint
{
    [HttpGet("page")]
    public IResponseResult EventPage(string index)
    {
        var settings = SettingsManager.Instance;
        var orm = new ORMContext(settings.Settings.ConnectionString);

        var data = new Dictionary<string, object>();
        var tour = orm.ReadById<Models.Tour>(int.Parse(index), "Tours");
        var program = JsonSerializer.Deserialize<List<ProgramDay>>(tour.TourProgram);

        data.Add("tour", tour);
        data.Add("tourPrograms", program);

        return Page("Static/Pages/EventPage.html", data);
    }
}
