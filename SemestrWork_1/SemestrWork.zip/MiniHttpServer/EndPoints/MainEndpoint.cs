﻿using MiniHttpServer.Framework.Attributes;
using MiniHttpServer.Framework.Core.Abstract;
using MiniHttpServer.Framework.share;
using MiniHttpServer.Models;
using MiniHttpServer.Services;
using MyORMLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MiniHttpServer.EndPoints;

[Endpoint("mainpage")]
public class MainEndpoint : BaseEndPoint
{
    [HttpGet()]
    public IResponseResult MainEndpointPage()
    {
        var settings = SettingsManager.Instance;
        var orm = new ORMContext(settings.Settings.ConnectionString);
        var tourCollection = orm.ReadByAll<Models.Tour>("Tours");


        var data = new Dictionary<string, object>();
        data.Add("tours", tourCollection);
        data.Add("userName", ((UserService)AuthService).GetUserBySession(Context.Request.Cookies["sessionId"]?.Value));

        return Page("Static/Pages/Main.html", data);
    }

    [HttpPost("registration")]
    public IResponseResult Registration()
    {
        var response = Context.Response;

        var username = FormData["UserLogin"];
        var password = FormData["UserPassword"];

        var auth = (UserService)AuthService;

        if (auth.ValidateUser(username, password) /*&& !auth.IsAuthorized(Context.Request)*/)
        {
            var sessionId = auth.CreateSession(username);

            // Создаем cookie
            //var sessionCookie = request.Cookies["sessionId"];
            var sessionCookie = new Cookie("sessionId", sessionId)
            {
                Expires = DateTime.Now.AddHours(24),
                HttpOnly = true,
                Path = "/"
            };

            response.Cookies.Add(sessionCookie);
        }

        if (auth.IsAdmin(username, password))
            return Redirect("/admin");

        return RefreshPage();
    }

    [HttpPost("redirect")]
    public IResponseResult MainRedirect()
    {
        return Redirect("/FuckGerman");
        //return RefreshPage();
    }

    [HttpGet("search")]
    public IResponseResult SearchEvent(string template)
    {
        var orm = new ORMContext(SettingsManager.Instance.Settings.ConnectionString);
        var events = orm.ReadByAll<Models.Tour>("Tours").ToList();

        var result = events
            .Where(e => e.Name.Contains(template, StringComparison.OrdinalIgnoreCase))
            .ToList();

        var data = new Dictionary<string, object>();
        data.Add("tours", result);

        return Page("Static/Pages/Main.html", data);
    }

    [HttpPost("filter")]
    public IResponseResult Filter()
    {
        var form = FormData;

        var orm = new ORMContext(SettingsManager.Instance.Settings.ConnectionString);
        var events = orm.ReadByAll<Models.Tour>("Tours").ToList();

        var result = FilterToursAdvanced(events, FormData);

        var data = new Dictionary<string, object>();
        data.Add("tours", result);

        return Page("Static/Pages/Main.html", data);
    }

    [HttpPost("admin")]
    public IResponseResult AdminPage()
    {
        return Redirect("/admin");
    }

    [HttpGet("showevent")]
    public IResponseResult ShowEventPage(string index)
    {
        return Redirect($"/event/page?index={index}");
    }

    private static List<Models.Tour> FilterToursAdvanced(List<Models.Tour> tours, Dictionary<string, string> formData)
    {
        var query = tours.AsQueryable();

        foreach (var filter in formData)
        {
            switch (filter.Key)
            {
                case "NightCount":
                    var nightValues = filter.Value.Split(',')
                        .Select(v => int.Parse(v.Trim()))
                        .ToList();
                    query = query.Where(t => nightValues.Contains(t.NightCount));
                    break;

                case "OrganizationType":
                    var orgValues = filter.Value.Split(',')
                        .Select(v => v.Trim())
                        .ToList();
                    query = query.Where(t => orgValues.Contains(t.OrganizationType));
                    break;

                case "WithFlight":
                    if (bool.Parse(filter.Value))
                        query = query.Where(t => t.WithFlight);
                    break;

                case "WithAccommodation":
                    if (bool.Parse(filter.Value))
                        query = query.Where(t => t.WithAccommodation);
                    break;

                case "WithFood":
                    if (bool.Parse(filter.Value))
                        query = query.Where(t => t.WithFood);
                    break;

                case "WeekendTour":
                    if (bool.Parse(filter.Value))
                        query = query.Where(t => t.WeekendTour);
                    break;

                case "LowCost":
                    if (bool.Parse(filter.Value))
                        query = query.Where(t => t.LowCost);
                    break;

                case "WithKids":
                    if (bool.Parse(filter.Value))
                        query = query.Where(t => t.WithKids);
                    break;
            }
        }

        return query.ToList();
    }

}
