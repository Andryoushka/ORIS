﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniHttpServer.Models;

public class TourProgram
{
    public List<ProgramDay> Days { get; set; }

}

public class ProgramDay
{
    public int Id { get; set; }
    public List<string> Tasks { get; set; }
}